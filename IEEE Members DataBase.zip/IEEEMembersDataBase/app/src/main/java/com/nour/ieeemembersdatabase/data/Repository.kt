package com.nour.ieeemembersdatabase.data

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.room.Insert
import androidx.room.Query
import com.nour.ieeemembersdatabase.data.room.LocalDB.getDatabaseInstance
import com.nour.ieeemembersdatabase.data.room.Member
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class Repository ( application: Application ) {
  val dao = getDatabaseInstance(application).getDataAccessObject()

  suspend fun insertMember(member: Member){
    dao.insertMember(member)
  }

  fun getAllMembers() :LiveData < List<Member> > = dao.getAllMembers()
}