package com.nour.ieeemembersdatabase.data.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface DataAccessObject {

    @Insert
   suspend fun insertMember(member: Member)
    @Insert
    suspend fun insertMember(member:List<Member>)
  @Query("SELECT * FROM Member")
    fun getAllMembers() :LiveData < List<Member> >

}