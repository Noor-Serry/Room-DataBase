package com.nour.ieeemembersdatabase.data.room

import android.app.Application
import androidx.room.Room

object LocalDB {
    private var instance : MemberDataBase? =null
    @Synchronized
    fun getDatabaseInstance(application: Application):MemberDataBase{
        if (instance==null)
            instance = Room.databaseBuilder(application,MemberDataBase::class.java,"MemberDataBase.db").build()
        return instance!!
    }
}