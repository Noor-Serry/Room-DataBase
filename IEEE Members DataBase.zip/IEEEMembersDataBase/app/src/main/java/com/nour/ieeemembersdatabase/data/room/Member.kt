package com.nour.ieeemembersdatabase.data.room


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Member(@PrimaryKey(autoGenerate = true)var id:Int=0, var name:String, var track :String, var phone:String)

