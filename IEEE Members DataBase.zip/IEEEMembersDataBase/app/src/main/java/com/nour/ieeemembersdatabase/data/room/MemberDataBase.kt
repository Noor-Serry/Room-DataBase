package com.nour.ieeemembersdatabase.data.room

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Member::class], version = 1)
abstract class MemberDataBase : RoomDatabase() {
    abstract fun getDataAccessObject() : DataAccessObject
}