package com.nour.ieeemembersdatabase.ui.home

import androidx.recyclerview.widget.DiffUtil
import com.nour.ieeemembersdatabase.data.room.Member

class DifferentMembers(private val oldMembers:List<Member>, private val newMembers:List<Member>): DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldMembers.size

    override fun getNewListSize(): Int = newMembers.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean  {
       return oldMembers[oldItemPosition].id == newMembers[newItemPosition].id
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = true
}