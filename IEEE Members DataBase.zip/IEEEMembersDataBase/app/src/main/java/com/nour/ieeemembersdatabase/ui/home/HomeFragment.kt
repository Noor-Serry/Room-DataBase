package com.nour.ieeemembersdatabase.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.nour.ieeemembersdatabase.R
import com.nour.ieeemembersdatabase.data.room.Member
import com.nour.ieeemembersdatabase.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {
    lateinit var binding : FragmentHomeBinding
    lateinit var viewModel : HomeViewMode
    lateinit var memberAdapter: MemberAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View {
        binding = FragmentHomeBinding.inflate(layoutInflater)
        viewModel = ViewModelProvider(requireActivity())[HomeViewMode::class.java]
        memberAdapter = MemberAdapter(ArrayList<Member>())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.memberRecyclerView.adapter = memberAdapter
        viewModel.members.observe(viewLifecycleOwner){
         memberAdapter.setMemberList(it)}

        binding.addNewMemberButton.setOnClickListener(this::goToMemberFragment)
    }

    private fun goToMemberFragment(view: View){
        findNavController().navigate(R.id.action_homeFragment_to_memberFragment)
    }


}