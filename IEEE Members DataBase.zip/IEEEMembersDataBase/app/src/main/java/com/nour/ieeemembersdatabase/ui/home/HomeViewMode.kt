package com.nour.ieeemembersdatabase.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel

import com.nour.ieeemembersdatabase.data.Repository


class HomeViewMode(application: Application) : AndroidViewModel(application)  {
    private val  repository = Repository(application)
     var  members = repository.getAllMembers()




}