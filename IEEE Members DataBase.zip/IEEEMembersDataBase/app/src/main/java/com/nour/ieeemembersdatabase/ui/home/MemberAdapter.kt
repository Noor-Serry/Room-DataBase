package com.nour.ieeemembersdatabase.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.marginBottom
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.nour.ieeemembersdatabase.R
import com.nour.ieeemembersdatabase.data.room.Member
import com.nour.ieeemembersdatabase.databinding.CustomMemberViewHolderBinding

class MemberAdapter(var members:List<Member>): RecyclerView.Adapter<MemberAdapter.Holder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.custom_member_view_holder,null)
        val binding = CustomMemberViewHolderBinding.bind(view)
        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
    holder.binding.member = members[position]
    }

    override fun getItemCount(): Int = members.size

     fun setMemberList(newMembers:List<Member>){
        val diffResult = DiffUtil.calculateDiff(DifferentMembers(members,newMembers))
        members = newMembers
        diffResult.dispatchUpdatesTo(this)
    }

    class Holder(val binding:CustomMemberViewHolderBinding) : RecyclerView.ViewHolder(binding.root)


}