package com.nour.ieeemembersdatabase.ui.newMember

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.nour.ieeemembersdatabase.data.Repository
import com.nour.ieeemembersdatabase.data.room.Member
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class NewMemberViewModel (application: Application) : AndroidViewModel(application)  {
    private val  repository = Repository(application)
    val name = MutableLiveData<String>()
    val track = MutableLiveData<String>()
    val phone = MutableLiveData<String>()

     fun saveNewMemberInLocalDB(){
        viewModelScope.launch(Dispatchers.IO) {
            val member = Member(name = name.value!!, phone =  phone.value!!, track =  track.value!!)
            repository.insertMember(member)
        }
    }



}