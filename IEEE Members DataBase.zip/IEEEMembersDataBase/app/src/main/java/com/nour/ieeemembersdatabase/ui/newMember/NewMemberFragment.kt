package com.nour.ieeemembersdatabase.ui.newMember

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.nour.ieeemembersdatabase.databinding.FragmentNewMemberBinding


class NewMemberFragment : Fragment() {

    lateinit var binding : FragmentNewMemberBinding
    lateinit var viewModel : NewMemberViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNewMemberBinding.inflate(layoutInflater)
        viewModel = ViewModelProvider(this)[NewMemberViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.saveButton.setOnClickListener(this::onClickSaveButton)
    }

    private fun onClickSaveButton(view: View){
        if(thereFieldIsEmpty())
            showToastFieldEmpty()
        else{
            viewModel.saveNewMemberInLocalDB()
            goToHomeFragment()
        }
    }

    private fun thereFieldIsEmpty():Boolean{
         with(binding){
             return nameEditText.text.isNullOrEmpty()
                     || phoneEditText.text.isNullOrEmpty()
                     || trackEditText.text.isNullOrEmpty()
        }
    }

    private fun showToastFieldEmpty(){
        Toast.makeText(requireContext(),"there is field is empty",Toast.LENGTH_SHORT).show()
    }

    private fun goToHomeFragment(){
        findNavController().popBackStack()
    }


}