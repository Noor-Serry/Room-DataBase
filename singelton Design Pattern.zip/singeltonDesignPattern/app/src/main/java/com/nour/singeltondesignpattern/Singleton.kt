package com.nour.singeltondesignpattern

class Singleton {

    companion object{
        private var singleton: Singleton? =null
        //we use this annotation to handel if two object needed instance in the same time not create two instances
        @Synchronized
        fun getSingletonInstance():Singleton{
            if (singleton == null)
                singleton = Singleton()
            return singleton!!
        }
    }
}